<?php include 'header.php'; ?>

<html>
<body>
<div id="message"></div>
<form id="from-data" action="/ci/index.php/home/insert" method="POST">
<input type="text" name='name' style='width:200px;height 40px;margin: 10px;' placeholder="name">
<input type="text" name='email' style='width:200px;height 40px;margin: 10px;' placeholder="email">
<input type="text" name='contact' style='width:200px;height 40px;margin: 10px;' placeholder="contact">
<input type="text" name='facebook' style='width:200px;height 40px;margin: 10px;' placeholder="facebook">
<input type="submit" value='submit'>
</form>

        <table class="table">
            <thead><tr><th>Name</th><th>Email</th><th>Contact</th><th>facebook link</th><th>created</th><th>Action</th></tr></thead>
            <tbody id="result">
            
            </tbody>
            <tfoot></tfoot>
        </table>
<script type="text/javascript">
$(document).ready(function(){
	showdata();
	$("#from-data").submit(function (e){
	
		e.preventDefault();
		var url=$(this).attr('action');
		var data=$(this).serialize();
		$.ajax({
			data:data,
			url:url,
			type:'POST',
			success:function(result){
				
				$("#message").html(result);

			}

		});
	});
function showdata(){
	var url="/ci/index.php/home/showdata";
	$.ajax({
			
			url:url,
			type:'GET',
			success:function(result){
				$("#result").html(result);
			}
		})
			
}



})	


</script>





</body>
</html>