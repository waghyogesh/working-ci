<?php

class Home extends CI_Controller
{

	public function __construct()
	{	 parent::__construct();
		$this->load->model('homemodel');
		
	}
	public function index()
	{
		$this->load->view('home_view');
	}
	public function insert()
	{
		$this->homemodel->insertdata();
	}
	public function showdata()
	{
		$this->homemodel->showdata();
	}
}


?>